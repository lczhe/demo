
<ol class="breadcrumb">
  <li><a href="#">Home</a></li>
  <li class="active">试题添加</li>
</ol>	
<button type="button" class="btn btn-warning"><a href="index.php?r=exam/index">试题展示</a></button>
<form role="form" action="index.php?r=exam/add_do" method="post" enctype="multipart/form-data"> 
	<div class="form-group">
      <label for="name">第几单元</label>
      <input type="text" class="form-control" id="name" 
         placeholder="请输入第几单元" name="unit">
   </div>
   <div class="form-group">
      <label for="inputfile">Excel试题文件导入</label>
      <input type="file" id="inputfile" name="excel">
      <p class="help-block">这是试题导入</p>
   </div>
   <button type="submit" class="btn btn-default">提交</button>
</form>