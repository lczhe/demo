 
<ol class="breadcrumb">
  <li><a href="#">Home</a></li>
  <li class="active">试题展示</li>
</ol>
<button type="button" class="btn btn-warning"><a href="index.php?r=exam/add">试题添加</a></button>


<table class="table table-striped">
   <caption>试题展示</caption>
   <thead>
      <tr>
         <th>题干</th>
         <th>月份</th>
         <th>单元</th>
         <th>时间</th>
         <th>出题人</th>
         <th>操作</th>
      </tr>
   </thead>
   <tbody>
      <?php foreach($data['data'] as $k=>$v){?>
         <tr>
            <td><?= $v['stem']?></td>
            <td><?= $v['month']?></td>
            <td><?= $v['unit']?></td>
            <td><?= date('Y-m-d H:i:s',$v['time'])?></td>
            <td><?= $v['person']?></td>
            <td>
               <button type="button" class="btn btn-info">修改</button>
               <button type="button" class="btn btn-danger">删除</button>
            </td>
         </tr>
      <?php }?>
   </tbody>
</table>
 <div id="box">
         <?php echo $page;?>
      </div>