<?php
namespace backend\controllers;

use Yii;
use yii\web\Controller;
use common\libs\curl;

header("content-type:text/html;charset=utf-8");
class ExamController extends Controller
{
	public $enableCsrfValidation = false;
		public function actionIndex()
		{
			// echo "1";exit;
			// $token = $this->token();
			// var_dump($token);exit;
			$get = yii::$app->request->get();
			$url = "http://47.93.233.90/yiinew/api/web/index.php?r=exam/show";
			$data = curl::_get($url);
			// var_dump($data);exit;
			$data = json_decode($data,true);
			// var_dump($data);exit;
			$page = $this->page($data['count'],$data['p'],$data['size']);
			$arr = array('data'=>$data,'page'=>$page);
			return $this->render('index',$arr);
		}
		public function actionAdd()
		{
			return $this->render('add');
		}
		public function actionAdd_do()
		{
			$data = Yii::$app->request->post();
			// var_dump($data);exit;
			$tmp_name = $_FILES['excel']['tmp_name'];
			$file = '/phpstudy/www/yiinew/backend/upload/xiti.xls';
			$res = move_uploaded_file($tmp_name,$file);
			if($res)
			{
				$url = "http://47.93.233.90/yiinew/api/web/index.php?r=exam/add";
				$excel['file'] = $file;
				$parm['unit'] = $data['unit'];
				$data = curl::_post($url,$parm,$excel);
				if($data)
				{
					$this->redirect('index.php?r=exam/index');
				}
			}
		}

		//封装的 分页

		public function page($count,$p,$size)
		{
			$start = $p-3 <1 ? 1 : $p-3;
				// echo $start;exit;
			$total = ceil($count/$size);

			$end = $p+5 >$total ? $total :$p+5;

			$str = '<ul class="pagination pagination-lg">';

			for($i=$start;$i<=$end;$i++)
			{
				if($i==$p)
				{
					 $str .= '<li class="active"><a href="javascript:void(0)" class="page" page="'.$i.'">'.$i.'</a></li>';
				}else{
					$str .= '<li><a href="javascript:void(0)" class="page" page="'.$i.'">'.$i.'</a></li>';
				}
			}
			$str .='</ul>';
			return $str;
		}
		// public function token($data=array())
		// {
		// 	$token = 'token';
		// 	$time  = time();
		// 	$data = json_encode($data);
		// 	$arr = array($token,$data,$time);
		// 	sort($arr);
		// 	basename($str);exit;
		// 	// $str = sha1($arr);
		// 	var_dump($arr);exit;
		// 	$info= array('encrypt'=>$str,'time'=>$time);
		// 	return $info;
		// }
}