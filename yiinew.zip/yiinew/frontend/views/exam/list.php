
<form action="index.php?r=exam/list_do" method="post">
	<div class="panel panel-primary">
		<?php $i=1; foreach ($data as $k => $v){

			$type = yii::$app->params['type'];
			?>
	   <div class="panel-heading">
	      <h3 class="panel-title"><?= $i;$i++;?>:[<?= $type[$v['type']]?>]<?= $v['stem']?></h3>
	   </div>

	   <?php $n = 'A'; foreach($v['answer'] as $key => $val){
	   	
	   	?>
			<?php if($v['type'] == 'p-2'){?>

				   <div class="panel-body">
				      <?= $n;?>:<input type="checkbox" value="<?= $val['aid']?>" name="answer[<?= $v['id']?>][]"><?= $val['option']?>
				   </div>

				<?php }else{?>
					 <div class="panel-body">
					  <?= $n;?>:<input type="radio" value="<?= $val['aid']?>" name="answer[<?= $v['id']?>]"><?= $val['option']?>
					 </div>
	    <?php } $n++;}?>
	   <?php }?>
	</div>
	<button type="submit" class="btn btn-primary">提交成绩</button>
</form>
