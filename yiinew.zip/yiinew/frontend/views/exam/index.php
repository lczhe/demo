<p>考试试题</p>
<form method="index.php" method="get">
      <input type="hidden" name="r" value="exam/list">
<?php foreach (yii::$app->params['month'] as $k => $v){ ?>
    <input type="checkbox"><?= $v?><br>
   <?php foreach (yii::$app->params['unit'] as $key=> $val){ ?>
       <input type="checkbox" value="<?= $key?>" name="unit[<?= $k?>][]"><?= $val?>
   <?php } ?>
   <br>
   <br>
<?php } ?>
<input type="submit" value="做试题">
</form>