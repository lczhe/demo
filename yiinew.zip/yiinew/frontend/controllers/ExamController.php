<?php
namespace frontend\controllers;

use Yii;
use yii\web\Controller;
use common\libs\curl;
class ExamController extends Controller
{
	public $enableCsrfValidation = false;
	public function actionIndex()
	{
		return $this->render('index');
	}
	public function actionList()
	{
		$get = yii::$app->request->get();
		$where = '1=1 AND (';
		foreach ($get['unit'] as $key => $value) {
			$where .= ' (month = '.$key.' AND ';
			$libs = implode(',',$value);
			$where.='unit in('.$libs.')) OR ';
		}
		$where = substr($where,0,strlen($where)-3);
		$where .=')';
		$url = "http://47.93.233.90/yiinew/api/web/index.php?r=exam/flist";
		$data = curl::_get($url,array('where'=>$where));
		// var_dump($data);
		$data = json_decode($data,true);
		return $this->render('list',['data'=>$data]);
	}
	public function actionList_do()
	{
		$post = yii::$app->request->post();
		$post=json_encode($post);
		$url = "http://47.93.233.90/yiinew/api/web/index.php?r=exam/result";
		$data = curl::_post($url,array('result'=>$post));
		var_dump($data);exit;
		$arr = array('num'=>$data);
		return $this->render('list_do',$arr);
	}
}