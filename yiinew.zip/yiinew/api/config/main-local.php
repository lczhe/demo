<?php
return [
    'components' => [
        'request' => [
            // !!! insert a secret key in the following (if it is empty) - this is required by cookie validation
            'cookieValidationKey' => 'K4f2IwjB5t1VxzNhNf9xvYlQ1J2KogN8',
        ],
    ],
];
