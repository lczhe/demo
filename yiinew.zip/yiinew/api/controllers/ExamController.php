<?php
namespace api\controllers;
use Yii;
use yii\web\Controller;
use common\libs\curl;
use api\controllers\CommenController;
header("content-type:text/html;charset=utf-8");
class ExamController extends CommenController
{
	public $enableCsrfValidation = false;
		public function actionAdd()//添加试题页
		{
			// var_dump($_FILES);
			$tmp_name = $_FILES['file']['tmp_name'];
			$file = '/phpstudy/www/yiinew/api/upload/xiti.xls';
			$res = move_uploaded_file($tmp_name,$file);
			if($res)
			{
				$unit = yii::$app->request->post('unit');
				require(__DIR__ . '/../../common/libs/PHPExcel.php');

				$excel = \PHPExcel_IOFactory::load($file);

				$data = $excel->getActiveSheet()->toArray(null,true,true,true);
					unset($data['1']);
					// var_dump($data);exit;
				foreach ($data as $key => $val) {
					$type = array_flip(Yii::$app->params['type']);
					$score = Yii::$app->params['score'];
					// var_dump($type);exit;
					$arr = array(
								'stem'=>$val['C'],
								'month'=>'9',
								'unit'=>'3',
								'type'=>$type[$val['B']],
								'time'=>time(),
								'value'=>$score[$type[$val['B']]],
								'person'=>$val['L']
							);

					Yii::$app->db->createCommand()->insert('subject',$arr)->execute();
					$sid = yii::$app->db->getLastInsertID();
					$choice = array('D'=>'A','E'=>'B','F'=>'C','G'=>'D','H'=>'E','I'=>'F');

					$corrent = str_split($val['J'],1);
					for($i='D';$i<='I';$i++)
					{
						if(empty($val[$i])) continue;
						
						$correct = in_array($choice[$i],$corrent) ? 1 : 0;

						$acinfo = array(
							'sid'=>$sid,
							'option'=>$val[$i],
							'correct'=>$correct
						);
						Yii::$app->db->createCommand()->insert('answer',$acinfo)->execute();
					}
				}
				echo "ok";

			}
		}
		public function actionShow()//题干展示页
		{
			$p = Yii::$app->request->get('p',1);//当前页
			$size = Yii::$app->request->get('size',5);//每页显示数量
			$where = $this->where();//搜索条件
			$count = yii::$app->db->createCommand("select count(*) count from subject where ".$where."")->queryAll();
			$count = $count[0]['count'];//总条数
			$limit = ($p-1)*$size;//偏移量
			$sql = "select * from subject where ".$where." limit ".$limit.",".$size."";
			$data = yii::$app->db->createCommand($sql)->queryAll();
			$arr = array('count'=>$count,'data'=>$data,'p'=>$p,'size'=>$size);
			echo json_encode($arr);
		}
		public function actionFlist()//查找单元试题
		{
			$get = Yii::$app->request->get();
			$score = yii::$app->params['score'];
			foreach ($score as $key => $va) {
				$limit = '20';
				if($key !='p-1')
				{
					$limit = '10';
				}
				$sql = "select * from answer join( select * from subject where type='".$key."' and ".$get['where']." order by rand() limit ".$limit.") as subject on subject.id = answer.sid order by rand()";
				$data[]= yii::$app->db->createCommand($sql)->queryAll();
			}
			$arr = array_merge($data['0'],$data['1'],$data['2']);
			foreach ($arr as $k => $v) {
				if(!isset($datainfo[$v['sid']]))
				{
					$datainfo[$v['sid']] = $v;
				}
				$datainfo[$v['sid']]['answer'][] = array(
							'option' => $v['option'],
							'aid'=>$v['aid']
				);
			}

			echo json_encode($datainfo);

		}
		public function actionResult()
		{
			$post = Yii::$app->request->post();
			$data = json_decode($post['result'],true);
			$keys = array_keys($data['answer']);
			$libs = implode(',',$keys);
			$sql = "select aid,sid,type from answer join subject on answer.sid = subject.id where sid in(".$libs.") and correct=1";
			$answer =  yii::$app->db->createCommand($sql)->queryAll();
			// var_dump($data);exit;
			$score = 0;
			foreach ($answer as $v) {
				if($v['type']=='p-2') continue;
				// echo "1";exit;
				if($v['aid'] == $data['answer'][$v['sid']])
				{
					$score += yii::$app->params['score'][$v['type']];
				}
			}
			echo $score;exit;
		}
		public function where()
		{
			$get = Yii::$app->request->get();
			$where = array("1=1");
			if(isset($get['stem'])&&!empty($get['stem']))
			{
				$where[] = "stem like '%".$get['stem']."%'";
			}
			if(isset($get['unit'])&&!empty($get['unit']))
			{
				$where[] = "unit ='".$get['unit']."'";
			}
			$where = implode(' and ', $where);
			return $where;
		}
}