<?php
namespace api\controllers;
use Yii;
use yii\web\Controller;
use common\libs\curl;
class CommenController extends Controller
{
	public function init()
	{
		// $arr = yii::$app->request->get();
		// 	$token = "token";
		// 	var_dump($arr);
		// 	exit;
	}
}